#include <stdlib.h>
#include <stdio.h>
#include <time.h>
  #include <sys/resource.h>
#include <errno.h>

typedef struct {
  char nlinhas;
  char ncolunas;
  char ncores;
  char **mapa;
} tmapa;


typedef struct {
  char coordX, coordY;
} tcoord;

typedef struct tcomponente{
  struct tcomponente **vizinhos; //CHECAR O PONTEIRO
  char cor;
  char estado; //indica se o componente sofreu merges
  unsigned int tamanho;  //contador de pontos
  tcoord * pontos; //pontos do componente
  
  unsigned int numVizinhos; //limita o vetor vizinhos
  unsigned int id;
} tcomponente;



typedef struct tnodo{
  struct tnodo **next; //lista de ponteiros para nodos
  tcomponente *componentes;
  unsigned int numComponentes;
  char status; //para a busca em profundidade
} tnodo;

void aloca_pontos(tcoord **pontos, unsigned int currentMax){
  *pontos = (tcoord * ) malloc (currentMax * sizeof(tcoord));
}

void aloca_vizinhos (tnodo * nodo, int currentMax) {
  nodo->componentes[nodo->numComponentes].vizinhos = (tcomponente **) malloc (currentMax * sizeof(tcomponente *));

}
void aloca_componentes(tcomponente **componentes, unsigned int currentMax) {
  *componentes = (tcomponente *) malloc(currentMax * sizeof(tcomponente));
 
 
}


void mostra_mapa(tmapa *m) {
  char i, j;

  printf("%d %d %d\n", m->nlinhas, m->ncolunas, m->ncores);
  for(i = 0; i < m->nlinhas; i++) {
    for(j = 0; j < m->ncolunas; j++)
      if(m->ncores > 10)
  printf("%02d ", m->mapa[i][j]);
      else
  printf("%d ", m->mapa[i][j]);
    printf("\n");
  }
}



int mostraVizinhos (tnodo * nodo) {
  int i;
  int j;
  int componentesRestantes =0;
  for (i = 0; i < nodo->numComponentes; ++i){
      if (nodo->componentes[i].id != 0) ++componentesRestantes;
    printf("Vizinhanca[%d]:\n",i);
      for (j = 0; j < nodo->componentes[i].numVizinhos; ++j) {
         printf("%d ",nodo->componentes[i].vizinhos[j]->id);
         
      }
      printf("\n");
   
  }

  return componentesRestantes;
}

void mostra_mapa_cor(tmapa *m) {
  char i, j;
  char* cor_ansi[] = { "\x1b[0m",
           "\x1b[31m", "\x1b[32m", "\x1b[33m",
           "\x1b[34m", "\x1b[35m", "\x1b[36m",
           "\x1b[37m", "\x1b[30;1m", "\x1b[31;1m",
           "\x1b[32;1m", "\x1b[33;1m", "\x1b[34;1m",
           "\x1b[35;1m", "\x1b[36;1m", "\x1b[37;1m" };

  if(m->ncores > 15) {
    mostra_mapa(m);
    return;
  }
  printf("=====================================\n"); //REMOVER DPS
  printf("%d %d %d\n", m->nlinhas, m->ncolunas, m->ncores);
  for(i = 0; i < m->nlinhas; i++) {
    for(j = 0; j < m->ncolunas; j++)
      if(m->ncores > 10)
  printf("%s%02d%s ", cor_ansi[m->mapa[i][j]], m->mapa[i][j], cor_ansi[0]);
      else
        if(m->mapa[i][j]>9){
            printf("%s%d%s ", cor_ansi[m->mapa[i][j]], m->mapa[i][j], cor_ansi[0]);
        }

        else {
          printf("%s%d%s  ", cor_ansi[m->mapa[i][j]], m->mapa[i][j], cor_ansi[0]);
        }

    printf("\n");
    
  }
  printf("=====================================\n"); //REMOVER DPS
}

void copia_mapa(tmapa *m, tmapa *n){

  //TODO desalocar o temporario
  n->nlinhas = m->nlinhas;
  n->ncolunas = m->ncolunas;
  n->ncores = m->ncores;
  char i, j;
  n->mapa = (char**) malloc(n->nlinhas * sizeof(char*));
  
  for(i = 0; i < n->nlinhas; i++){
    n->mapa[i] = (char*) malloc(n->ncolunas * sizeof(char)); 

    for(j = 0; j < n->ncolunas; j++){
      n->mapa[i][j] = m->mapa[i][j];
    }

  }   
   

}

void copia_nodo(tnodo * pai, tnodo * filho){

}

int saoVizinhosCadastrados(tcomponente * amostra, tcomponente * pivo) {
  unsigned int i,j;
  
 printf("\n");
  for (i = 0; i < amostra->numVizinhos; ++i){

   // printf("%d == %d ?\n",amostra->vizinhos[i]->id,pivo->id);
    if (amostra->vizinhos[i]->id == pivo->id) { //é vizinho já cadastrado
      return 1;
    }
  }
  return 0; 
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
void mergeRoot (tnodo* nodo, char nextColor) { //////////CHECAR ESTA FUNC!!!!!!!!!!!!!!!!!!!!!! 
  int i,j,k;  ///////////////////////////////////////////////////////////////////////////////////////////////
  int flag1, flag2;
  flag1 = 0;
  flag2 = 0;
  
  
  tcomponente* raiz = &nodo->componentes[0];
  tcomponente** vizinhoIndireto; 
  tcomponente** vizinhoDireto;
  tcomponente** segundoPonteiroDireto;    // Raiz -> vizinhoDireto -> vizinhoIndireto
                                         //                ^              |
                                         //                |----segundo---

  int offsetVizinhos = raiz->numVizinhos;
  
  for (i = 0; i< raiz->numVizinhos; ++i) { //percorre todos os vizinhos do nodo raíz
    
    if(raiz->vizinhos[i]->cor == nextColor ) { //se o vizinho direto tem a cor = nextColor
      
      vizinhoDireto = &raiz->vizinhos[i];

      (*vizinhoDireto)->id = 0;
      (*vizinhoDireto)->estado = 0;

     // printf("@@@merging %d@@@\n",(*vizinhoDireto)->id);

      for(j = 0; j < (*vizinhoDireto)->numVizinhos; ++j ) { //pega os vizinhos dos novos componentes a serem absorvidos
      
        
        vizinhoIndireto = &((*vizinhoDireto)->vizinhos[j]); //vizinhos dos componentes absorvidos

        if  ( (*vizinhoIndireto)->id == raiz->id ) continue;      
        
        if(!saoVizinhosCadastrados(raiz,(*vizinhoIndireto))) {
          flag1 = 1;
        //  raiz->vizinhos[offsetVizinhos] = (*vizinhoIndireto);
        //  ++offsetVizinhos;
        }
          for (k = 0; k < (*vizinhoIndireto)->numVizinhos; ++k ) { //vizinhos dos vizinhos
            segundoPonteiroDireto = &((*vizinhoIndireto)->vizinhos[k]);

            if(!saoVizinhosCadastrados(raiz,(*segundoPonteiroDireto))) {
              raiz->vizinhos[offsetVizinhos] = *segundoPonteiroDireto;
              ++offsetVizinhos;
            }

          }
    

      }

    }
    if (flag1) {
      raiz->vizinhos[offsetVizinhos] = (*vizinhoIndireto);
      ++offsetVizinhos;
      flag1=0;
    }
  }
  raiz->numVizinhos = offsetVizinhos;
  nodo->componentes[0].cor = nextColor;
}





void search_component(char x, char y, tnodo *nodo) {
//  printf("\n{%d,%d}\n",x,y);
  int i;
  tcomponente * vizinho;
  int current = nodo->numComponentes;

  for (i = 0; i < current; ++i) {
    
    if (1){//nodo->componentes[i].cor != nodo->componentes[current].cor )  { //se as cores forem diferentes

      int a;
   //   printf("componente %d :",i);
      for (a = 0; a < nodo->componentes[i].tamanho ;++a){
      //    printf("|%d,%d|\n",nodo->componentes[i].pontos[a].coordX,nodo->componentes[i].pontos[a].coordY); 
          if(x == nodo->componentes[i].pontos[a].coordX && y == nodo->componentes[i].pontos[a].coordY && !saoVizinhosCadastrados(&nodo->componentes[i],&nodo->componentes[current]) ) { //se o vizinho existe
              //adiciona vizinhos
      //      printf("[%d,%d]\n",x,y);

            nodo->componentes[i].vizinhos[nodo->componentes[i].numVizinhos] = &nodo->componentes[current];
            nodo->componentes[current].vizinhos[nodo->componentes[current].numVizinhos] = &nodo->componentes[i];
            nodo->componentes[i].numVizinhos+=1;
            nodo->componentes[current].numVizinhos+=1;

         //   printf("%d <-> %d\n",current,i);

            return;

          }

      } 
      //   printf("\n");
    }    
       
   
  }


}




void componentes (tnodo *nodo, tmapa *temp, char l, char c, char cor) { //consome a matriz de char inicial para gerar um grafo
  

   if(cor == 0) return; //já visitado
 

   else {

       temp->mapa[l][c] = 0;

   //    printf ("(%d,%d) ",l,c );
       char tamanho = nodo->componentes[nodo->numComponentes].tamanho;
       
       nodo->componentes[nodo->numComponentes].pontos[tamanho].coordX = l;
       nodo->componentes[nodo->numComponentes].pontos[tamanho].coordY = c;        
       nodo->componentes[nodo->numComponentes].tamanho +=1;

       if(l < temp->nlinhas - 1) {
         if(temp->mapa[l+1][c] == cor ) {
          /*nodo->componentes[nodo->numComponentes].pontos[tamanho].coordX = l;
          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordY = c;
          nodo->componentes[nodo->numComponentes].tamanho +=1; */
          componentes(nodo, temp, l+1, c, cor);
         }

         else if (temp->mapa[l+1][c] == 0) { //já foi inserido como componente
           search_component(l+1,c,nodo); 
         } 

       }
       
       if(c < temp->ncolunas - 1) {
         if( temp->mapa[l][c+1] == cor ) {
          /*nodo->componentes[nodo->numComponentes].pontos[tamanho].coordX = l;
          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordY = c;
          nodo->componentes[nodo->numComponentes].tamanho +=1; */
          componentes(nodo, temp, l, c+1, cor);
         }

         else if (temp->mapa[l][c+1] == 0) { //já foi inserido como componente
           search_component(l,c+1,nodo);  
         } 

       }     

       if(l > 0) {
         if( temp->mapa[l-1][c] == cor) {
          /*nodo->componentes[nodo->numComponentes].pontos[tamanho].coordX = l;
          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordY = c;
          nodo->componentes[nodo->numComponentes].tamanho +=1; */
          componentes(nodo, temp, l-1, c, cor);
         }

         else if (temp->mapa[l-1][c] == 0) { //já foi inserido como componente
           search_component(l-1,c,nodo);  
         } 

       } 

       if(c > 0) {
         if( temp->mapa[l][c-1] == cor) {
          /*nodo->componentes[nodo->numComponentes].pontos[tamanho].coordX = l;
          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordY = c;
          nodo->componentes[nodo->numComponentes].tamanho +=1; */
          componentes(nodo, temp, l, c-1, cor);
         }

         else if (temp->mapa[l][c-1] == 0) { //já foi inserido como componente
           search_component(l,c-1,nodo);  
         } 

       } 


   }

}

void get_componentes (tnodo *nodo, tmapa *m) {
  char l ;
  char c ;
  char cor;
  tmapa temp;
   
  copia_mapa(m,&temp);
  nodo->numComponentes = 0;
  nodo->componentes = NULL;
  aloca_componentes(&(nodo->componentes),1000);
  for(l = 0; l < m->nlinhas; l++){
    for(c = 0; c < m->ncolunas; c++){
       cor = temp.mapa[l][c];  
       if(cor != 0) {
          
          nodo->componentes[nodo->numComponentes].cor = cor; //cor do novo componente
          nodo->componentes[nodo->numComponentes].tamanho = 0; //cor do novo componente
          nodo->componentes[nodo->numComponentes].id = nodo->numComponentes; //cor do novo componente
           nodo->componentes[nodo->numComponentes].estado = 1; //não sofreu merges
          aloca_pontos(&(nodo->componentes[nodo->numComponentes].pontos),200);
          aloca_vizinhos(nodo,200); 
          
          /////////////////////////////////////////////TODO MALLOC NOS COMPONENTES E GERAR VIZINHOS////////////////////////////////////////////////////
          //printf("/////////////////componente_id = %d /////////////////////\n",nodo->numComponentes);
          componentes(nodo, &temp, l, c,cor);
         // printf("\n");
         
         // mostra_mapa_cor(&temp);

       //   printf("|cor = %d ",cor);
     //     printf("area = %d |\n",nodo->componentes[nodo->numComponentes].tamanho+1);
          
          nodo->numComponentes+=1;
       }

    }
  }

  for (l = 0; l <nodo->numComponentes; ++l) {
    free((nodo->componentes[nodo->numComponentes].pontos));
  }
  


 

}


void gera_mapa(tmapa *m, int semente) {
  char i, j;

  if(semente < 0)
    srand(time(NULL));  
  else
    srand(semente);  
  m->mapa = (char**) malloc(m->nlinhas * sizeof(char*));
    for(i = 0; i < m->nlinhas; i++) {
    m->mapa[i] = (char*) malloc(m->ncolunas * sizeof(char));
    for(j = 0; j < m->ncolunas; j++)
      m->mapa[i][j] = 1 + rand() % m->ncores;
  }
}

void carrega_mapa(tmapa *m) {
  char i, j;

  scanf("%d",(int *) &(m->nlinhas));
  scanf("%d",(int *) &(m->ncolunas));
  scanf("%d",(int *) &(m->ncores));
  m->mapa = (char**) malloc(m->nlinhas * sizeof(char*));
  for(i = 0; i < m->nlinhas; i++) {
    m->mapa[i] = (char*) malloc(m->ncolunas * sizeof(char));
    for(j = 0; j < m->ncolunas; j++)
      scanf("%d",(int *) &(m->mapa[i][j]));
  }
}





void pinta(tmapa *m, char l, char c, char fundo, char cor) {
  m->mapa[l][c] = cor;
  if(l < m->nlinhas - 1 && m->mapa[l+1][c] == fundo)
    pinta(m, l+1, c, fundo, cor);
  if(c < m->ncolunas - 1 && m->mapa[l][c+1] == fundo)
    pinta(m, l, c+1, fundo, cor);
  if(l > 0 && m->mapa[l-1][c] == fundo)
    pinta(m, l-1, c, fundo, cor);
  if(c > 0 && m->mapa[l][c-1] == fundo)
    pinta(m, l, c-1, fundo, cor);
}

void pinta_mapa(tmapa *m, char cor) {
  if(cor == m->mapa[0][0])
    return;
  pinta(m, 0, 0, m->mapa[0][0], cor);
}

int main(int argc, char **argv) {
  char cor;
  tnodo campo;
  int semente;
  tmapa m;

  if(argc < 4 || argc > 5) {
    printf("uso: %s <numero_de_linhas> <numero_de_colunas> <numero_de_cores> [<semente_aleatoria>]\n", argv[0]);
    exit(1);
  }

  m.nlinhas = atoi(argv[1]);
  m.ncolunas = atoi(argv[2]);
  m.ncores = atoi(argv[3]);



 // grafo.vizinhos =(tcomponenteCor *) malloc(grafo.m.ncores*sizeof(tcomponenteCor)); //aloca vetor de componentes vizinhos

  if(argc == 5)
    semente = atoi(argv[4]);
  else
    semente = -1;
  gera_mapa(&m, semente);
  mostra_mapa_cor(&m);

  get_componentes(&(campo),&m);
  
  mostraVizinhos(&(campo));
  mostra_mapa_cor(&m);



errno = 0;
struct rusage* memory = malloc(sizeof(struct rusage));
getrusage(RUSAGE_SELF, memory);
if(errno == EFAULT)
    printf("Error: EFAULT\n");
else if(errno == EINVAL)
    printf("Error: EINVAL\n");
printf("Usage: %ld\n", memory->ru_ixrss);
printf("Usage: %ld\n", memory->ru_isrss);
printf("Usage: %ld\n", memory->ru_idrss);
printf("Max: %ld\n", memory->ru_maxrss);  //////////////PARA CHECAR MEMORIAAAA!!!!


  

  scanf("%d",(int *) &cor);//resposta do SMA-Star
  mergeRoot(&campo,cor);
  
  while(cor > 0) {
    mostra_mapa_cor(&m);
    printf("componentes restantes: %d\n",mostraVizinhos(&(campo)));
    printf("Max: %ld\n", memory->ru_maxrss); 
   // pinta_mapa(&(campo.m), cor);
   // mostra_mapa_cor(&(campo.m)); // para mostrar sem cores use mostra_mapa(&m);
    scanf("%d",(int *) &cor);
    mergeRoot(&campo,cor);
  }

  return 0;
}
