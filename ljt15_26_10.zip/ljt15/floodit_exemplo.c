#include <stdlib.h>
#include <stdio.h>
#include <time.h>

typedef struct {
  char nlinhas;
  char ncolunas;
  char ncores;
  char **mapa;
} tmapa;


typedef struct {
  char coordX, coordY;
} tcoord;

typedef struct tcomponente{
  struct tcomponente *vizinhos;
  char cor;
  unsigned int tamanho;  //contador de pontos
  tcoord * pontos; //pontos do componente
  
  unsigned int numVizinhos; //limita o vetor next
  unsigned int id;
} tcomponente;



typedef struct tnodo{
  struct tnodo **next; //lista de ponteiros para nodos
  tcomponente *componentes;
  unsigned int numComponentes;
  char status; //para a busca em profundidade
} tnodo;




int saoVizinhos(tcomponente * amostra, tcomponente * pivo) {
  unsigned int i,j;
  

  for (i = 0; i < amostra->numVizinhos; ++i){
    ////////////TODO
    ////////////REVER SE TA CERTO MERMO
    if (&amostra->vizinhos[i] == &pivo) { //é vizinho já cadastrado
      return 1;
    }
  }
  return 0; 
}

tcomponente search_component(char x, char y, tnodo *nodo) {
/*  unsigned int i;
  tcomponente * vizinho;
  unsigned int current = nodo->numComponentes;
  ///////////////////////
  //TODO CHECAR AQUIIII!!!
  ///////////////////////
  for (i = 0; i < current-1; ++i) {
    
    if (nodo->componentes[i].cor != nodo->componentes[current].cor ){//&& !saoVizinhos(nodo->componentes[i],nodo->componentes[current]) ) { //se as cores forem diferentes

      unsigned int a;
      for (a = 0; a < nodo->componentes[i].tamanho ;++a){
          if(x == nodo->componentes[i].pontos[a].coordX && y == nodo->componentes[i].pontos[a].coordY) { //se o vizinho existe
              //adiciona vizinhos
          }

      }

    }    
       
     
  }
*/

}

void aloca_pontos(tcoord **pontos, unsigned int currentMax){
  *pontos = (tcoord * ) malloc (currentMax * sizeof(tcoord));
}


void aloca_componentes(tcomponente **componentes, unsigned int currentMax) {
  *componentes = (tcomponente *) malloc(currentMax * sizeof(tcomponente));
 

}
void mostra_mapa(tmapa *m) {
  char i, j;

  printf("%d %d %d\n", m->nlinhas, m->ncolunas, m->ncores);
  for(i = 0; i < m->nlinhas; i++) {
    for(j = 0; j < m->ncolunas; j++)
      if(m->ncores > 10)
  printf("%02d ", m->mapa[i][j]);
      else
  printf("%d ", m->mapa[i][j]);
    printf("\n");
  }
}

void mostra_mapa_cor(tmapa *m) {
  char i, j;
  char* cor_ansi[] = { "\x1b[0m",
           "\x1b[31m", "\x1b[32m", "\x1b[33m",
           "\x1b[34m", "\x1b[35m", "\x1b[36m",
           "\x1b[37m", "\x1b[30;1m", "\x1b[31;1m",
           "\x1b[32;1m", "\x1b[33;1m", "\x1b[34;1m",
           "\x1b[35;1m", "\x1b[36;1m", "\x1b[37;1m" };

  if(m->ncores > 15) {
    mostra_mapa(m);
    return;
  }
  printf("%d %d %d\n", m->nlinhas, m->ncolunas, m->ncores);
  for(i = 0; i < m->nlinhas; i++) {
    for(j = 0; j < m->ncolunas; j++)
      if(m->ncores > 10)
  printf("%s%02d%s ", cor_ansi[m->mapa[i][j]], m->mapa[i][j], cor_ansi[0]);
      else
        if(m->mapa[i][j]>9){
            printf("%s%d%s ", cor_ansi[m->mapa[i][j]], m->mapa[i][j], cor_ansi[0]);
        }

        else {
          printf("%s%d%s  ", cor_ansi[m->mapa[i][j]], m->mapa[i][j], cor_ansi[0]);
        }

    printf("\n");
  }
}

void copia_mapa(tmapa *m, tmapa *n){

  //TODO desalocar o temporario
  n->nlinhas = m->nlinhas;
  n->ncolunas = m->ncolunas;
  n->ncores = m->ncores;
  char i, j;
  n->mapa = (char**) malloc(n->nlinhas * sizeof(char*));
  
  for(i = 0; i < n->nlinhas; i++){
    n->mapa[i] = (char*) malloc(n->ncolunas * sizeof(char)); 

    for(j = 0; j < n->ncolunas; j++){
    //  printf("%d ", m->mapa[i][j]);
      n->mapa[i][j] = m->mapa[i][j];
    }
    //printf("\n"); 
  }   
   

}

void componentes (tnodo *nodo, tmapa *temp, char l, char c, char cor) {
  

   if(cor == 0) return; //já visitado
 

   else {

       temp->mapa[l][c] = 0;
       printf ("(%d,%d) ",l,c );
       char tamanho = nodo->componentes[nodo->numComponentes].tamanho;

       if(l < temp->nlinhas - 1 &&  temp->mapa[l+1][c] == cor ) {

          

          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordX = l;
          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordY = c;

          
          nodo->componentes[nodo->numComponentes].tamanho +=1;
          componentes(nodo, temp, l+1, c, cor);
       }

       else  {
          if (temp->mapa[l+1][c] == 0) { //já foi inserido como componente
          search_component(l+1,c,nodo); 
          } 
          
       }
    
       if(c < temp->ncolunas - 1 && temp->mapa[l][c+1] == cor){
          

          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordX = l;
          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordY = c;

          nodo->componentes[nodo->numComponentes].tamanho +=1;

          componentes(nodo, temp, l, c+1, cor);
       }

       else  {
          if (temp->mapa[l][c+1] == 0) { //já foi inserido como componente
        //  search_component(l,c+1,nodo); 
          } 
          
       }

       if(l > 0 && temp->mapa[l-1][c] == cor){


          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordX = l;
          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordY = c;

          nodo->componentes[nodo->numComponentes].tamanho +=1;

          componentes(nodo, temp, l-1, c, cor);
       }
       else  {
          if (temp->mapa[l-1][c] == 0) { //já foi inserido como componente
         // search_component(l-1,c,nodo); 
          } 
          
       }
       if(c > 0 && temp->mapa[l][c-1] == cor){

          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordX = l;
          nodo->componentes[nodo->numComponentes].pontos[tamanho].coordY = c;

          nodo->componentes[nodo->numComponentes].tamanho +=1;

          componentes(nodo, temp, l, c-1, cor);
       }
       else  {
          if (temp->mapa[l][c-1] == 0) { //já foi inserido como componente
          //search_component(l,c-1,nodo); 
          } 
          
       }



   }

}

void get_componentes (tnodo *nodo, tmapa *m) {
  char l ;
  char c ;
  char cor;
  tmapa temp;
   
  copia_mapa(m,&temp);
  nodo->numComponentes = 0;
  nodo->componentes = NULL;
  aloca_componentes(&(nodo->componentes),1000);
  for(l = 0; l < m->nlinhas; l++){
    for(c = 0; c < m->ncolunas; c++){
       cor = temp.mapa[l][c];  
       if(cor != 0) {
          
          nodo->componentes[nodo->numComponentes].cor = cor; //cor do novo componente
          nodo->componentes[nodo->numComponentes].tamanho = 0; //cor do novo componente
          aloca_pontos(&(nodo->componentes[nodo->numComponentes].pontos),100);
          
          /////////////////////////////////////////////TODO MALLOC NOS COMPONENTES E GERAR VIZINHOS////////////////////////////////////////////////////
          componentes(nodo, &temp, l, c,cor);
          printf("\n");
          nodo->numComponentes+=1;
          mostra_mapa_cor(&temp);
          printf("cor = %d ",cor);
          printf("%d \n",nodo->numComponentes);
       }

    }
  }
  
 

}


void gera_mapa(tmapa *m, int semente) {
  char i, j;

  if(semente < 0)
    srand(time(NULL));  
  else
    srand(semente);  
  m->mapa = (char**) malloc(m->nlinhas * sizeof(char*));
    for(i = 0; i < m->nlinhas; i++) {
    m->mapa[i] = (char*) malloc(m->ncolunas * sizeof(char));
    for(j = 0; j < m->ncolunas; j++)
      m->mapa[i][j] = 1 + rand() % m->ncores;
  }
}

void carrega_mapa(tmapa *m) {
  char i, j;

  scanf("%d", &(m->nlinhas));
  scanf("%d", &(m->ncolunas));
  scanf("%d", &(m->ncores));
  m->mapa = (char**) malloc(m->nlinhas * sizeof(char*));
  for(i = 0; i < m->nlinhas; i++) {
    m->mapa[i] = (char*) malloc(m->ncolunas * sizeof(char));
    for(j = 0; j < m->ncolunas; j++)
      scanf("%d", &(m->mapa[i][j]));
  }
}





void pinta(tmapa *m, char l, char c, char fundo, char cor) {
  m->mapa[l][c] = cor;
  if(l < m->nlinhas - 1 && m->mapa[l+1][c] == fundo)
    pinta(m, l+1, c, fundo, cor);
  if(c < m->ncolunas - 1 && m->mapa[l][c+1] == fundo)
    pinta(m, l, c+1, fundo, cor);
  if(l > 0 && m->mapa[l-1][c] == fundo)
    pinta(m, l-1, c, fundo, cor);
  if(c > 0 && m->mapa[l][c-1] == fundo)
    pinta(m, l, c-1, fundo, cor);
}

void pinta_mapa(tmapa *m, char cor) {
  if(cor == m->mapa[0][0])
    return;
  pinta(m, 0, 0, m->mapa[0][0], cor);
}

int main(int argc, char **argv) {
  char cor;
  tnodo campo;
  int semente;
  tmapa m;

  if(argc < 4 || argc > 5) {
    printf("uso: %s <numero_de_linhas> <numero_de_colunas> <numero_de_cores> [<semente_aleatoria>]\n", argv[0]);
    exit(1);
  }

  m.nlinhas = atoi(argv[1]);
  m.ncolunas = atoi(argv[2]);
  m.ncores = atoi(argv[3]);



 // grafo.vizinhos =(tcomponenteCor *) malloc(grafo.m.ncores*sizeof(tcomponenteCor)); //aloca vetor de componentes vizinhos

  if(argc == 5)
    semente = atoi(argv[4]);
  else
    semente = -1;
  gera_mapa(&m, semente);
  mostra_mapa_cor(&m);

  get_componentes(&(campo),&m);

  scanf("%d", &cor);//resposta do SMA-Star
  while(cor > 0) {
    
   // pinta_mapa(&(campo.m), cor);
   // mostra_mapa_cor(&(campo.m)); // para mostrar sem cores use mostra_mapa(&m);
    scanf("%d", &cor);
  }

  return 0;
}
